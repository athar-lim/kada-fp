# **App Name**: CineTrack

## Core Features:

- Firebase Project and Firestore Configuration: Set up the Firebase project and configure Firestore for data storage and access.
- Firestore Data Model Definition: Implement the specified Firestore data model including collections for films, locations, studios, showtimes, tickets, and seat categories.
- Dummy Data Seeding Script: Develop a script to populate Firestore with realistic dummy data, including locations, films, showtimes (with cancelled/delayed statuses), and ticket transactions, adhering to specified quantity and price ranges.
- Admin Authentication: Secure login functionality for administrators using Firebase Authentication to restrict access to the dashboard.
- Basic Sidebar Navigation UI: Implement a foundational single-page layout with a sidebar for navigation to different (future) dashboard sections.

## Style Guidelines:

- The primary color, reflecting the 'primary accent' specified, is a bold dark red (#E24B4A) to convey a sense of urgency and importance, suitable for a dynamic dashboard.
- The background color is a very light, subtle reddish-white (#F8F3F3). This highly desaturated shade of the primary hue maintains brand consistency while ensuring high readability on a light theme.
- An accent color of deep rose (#BF406F) is used to draw attention to interactive elements and secondary data points. It is analogous to the primary red but provides a distinct visual contrast.
- Both headlines and body text will use the 'Inter' sans-serif font. Its modern, objective, and highly legible design ensures clarity and professionalism, ideal for presenting analytical data.
- The dashboard will adopt a responsive layout, ensuring optimal viewing experience across various devices, adhering to a clean and minimal design philosophy.
- Utilize a consistent set of minimal, outline-style icons to represent various dashboard sections and filtering options, complementing the clean UI.
- Implement subtle loading animations and smooth transitions for data updates and section changes to provide a polished and responsive user experience.