'use client';

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Line,
  LineChart
} from "recharts";
import { ArrowUp, Ticket, DollarSign, Building, Percent, Bell, ShieldAlert, CircleCheck, Info, WifiOff, CalendarDays, MapPin, Film, Users, MoreHorizontal, User, Activity } from "lucide-react";
import React, { useState, MouseEvent } from 'react';
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useUser } from "@/firebase";
import Link from "next/link";
import { Label } from "@/components/ui/label";

// ===========================
// DATA (Hardcoded)
// ===========================

const notificationsData = [
    {
        type: 'WARNING', title: 'Okupansi Rendah — Semarang', icon: <ShieldAlert className="h-5 w-5 text-amber-400"/>,
        description: 'Cineplex Semarang Central turun ke 38%, di bawah threshold 40%', time: '01:42 WIB', colorClass: 'bg-amber-500', read: false,
        history: [
            { status: 'Triggered', time: '24 Mar 2026, 01:42 WIB', detail: 'Occupancy dropped to 38%' },
            { status: 'Notified', time: '24 Mar 2026, 01:42 WIB', detail: 'Admin group A notified' },
        ]
    },
    {
        type: 'ALERT', title: 'Node Offline — Palembang', icon: <WifiOff className="h-5 w-5 text-red-500"/>,
        description: 'CineTrack tidak merespons sejak pukul 08:15 WIB', time: '06:17 WIB', colorClass: 'bg-red-500', read: false,
        history: [
            { status: 'Offline', time: '24 Mar 2026, 08:15 WIB', detail: 'No heartbeat received from Palembang node.' },
            { status: 'Alert', time: '24 Mar 2026, 08:16 WIB', detail: 'Critical alert sent to on-call engineer.' },
            { status: 'Investigating', time: '24 Mar 2026, 08:20 WIB', detail: 'On-call engineer acknowledged the alert.' },
        ]
    },
    {
        type: 'SUCCESS', title: 'Rekor Baru — Jakarta Barat', icon: <CircleCheck className="h-5 w-5 text-green-500"/>,
        description: 'Penjualan harian tertinggi: 1,306 tiket dalam sehari', time: '01:83 WIB', colorClass: 'bg-green-500', read: false,
        history: [
            { status: 'Milestone', time: '24 Mar 2026, 00:01 WIB', detail: 'Daily sales record for CGV Jakarta Barat broken.' },
        ]
    },
    {
        type: 'INFO', title: 'Rilis Besok — Nusantara Rising', icon: <Info className="h-5 w-5 text-blue-500"/>,
        description: 'Proyeksi demand tinggi, semua studio diaktifkan penuh', time: 'Kemarin 18:00', colorClass: 'bg-blue-500', read: true,
        history: [
            { status: 'Info', time: '23 Mar 2026, 18:00 WIB', detail: 'High demand projected for new release.' },
        ]
    }
];

const liveTransactions = [
  { city: 'Bandung', movie: 'Dune: Bagian Tiga', tickets: 2, time: '22:41' },
  { city: 'Surabaya', movie: 'Nusantara Chronicles', tickets: 4, time: '22:40' },
  { city: 'Jakarta Barat', movie: 'Avatar 3', tickets: 1, time: '22:40' },
  { city: 'Jakarta Timur', movie: 'Siksa Kubur 2', tickets: 2, time: '22:39' },
];

const hourlyOccupancyData = [
  { hour: '10:00', Okupansi: 35 }, { hour: '11:00', Okupansi: 45 },
  { hour: '12:00', Okupansi: 60 }, { hour: '13:00', Okupansi: 65 },
  { hour: '14:00', Okupansi: 70 }, { hour: '15:00', Okupansi: 75 },
  { hour: '16:00', Okupansi: 80 }, { hour: '17:00', Okupansi: 82 },
  { hour: '18:00', Okupansi: 85 }, { hour: '19:00', Okupansi: 95 },
  { hour: '20:00', Okupansi: 90 }, { hour: '21:00', Okupansi: 88 },
  { hour: '22:00', Okupansi: 70 }, { hour: '23:00', Okupansi: 50 },
];

const topFilmsData = [
    { rank: 1, title: "Dune: Bagian Tiga", tickets: "4,820", revenue: "241M" },
    { rank: 2, title: "Nusantara Chronicles", tickets: "3,910", revenue: "198M" },
    { rank: 3, title: "Avatar 3", tickets: "3,240", revenue: "162M" },
    { rank: 4, title: "Siksa Kubur 2", tickets: "2,780", revenue: "139M" },
    { rank: 5, title: "Iron Man: Legacy", tickets: "2,180", revenue: "109M" },
    { rank: 6, title: "Civil War", tickets: "1,980", revenue: "99M" },
    { rank: 7, title: "Godzilla x Kong", tickets: "1,750", revenue: "87M" },
];

const cityData = [
    { id: 'jakarta', name: 'Jakarta', province: 'DKI Jakarta', cx: 400, cy: 400, tickets: 12000, revenue: 600000000, occupancy: 88 },
    { id: 'bandung', name: 'Bandung', province: 'Jawa Barat', cx: 420, cy: 415, tickets: 8000, revenue: 320000000, occupancy: 82 },
    { id: 'surabaya', name: 'Surabaya', province: 'Jawa Timur', cx: 500, cy: 420, tickets: 9500, revenue: 380000000, occupancy: 85 },
    { id: 'medan', name: 'Medan', province: 'Sumatra Utara', cx: 200, cy: 250, tickets: 7000, revenue: 280000000, occupancy: 78 },
    { id: 'makassar', name: 'Makassar', province: 'Sulawesi Selatan', cx: 650, cy: 350, tickets: 6500, revenue: 260000000, occupancy: 75 },
    { id: 'denpasar', name: 'Denpasar', province: 'Bali', cx: 580, cy: 440, tickets: 8500, revenue: 425000000, occupancy: 92 },
    { id: 'palembang', name: 'Palembang', province: 'Sumatra Selatan', cx: 300, cy: 320, tickets: 5000, revenue: 175000000, occupancy: 70 },
    { id: 'samarinda', name: 'Samarinda', province: 'Kalimantan Timur', cx: 580, cy: 200, tickets: 4500, revenue: 157500000, occupancy: 68 },
    { id: 'jayapura', name: 'Jayapura', province: 'Papua', cx: 900, cy: 300, tickets: 3000, revenue: 120000000, occupancy: 65 },
    { id: 'semarang', name: 'Semarang', province: 'Jawa Tengah', cx: 460, cy: 410, tickets: 6000, revenue: 210000000, occupancy: 79 },
    { id: 'yogyakarta', name: 'Yogyakarta', province: 'DI Yogyakarta', cx: 455, cy: 425, tickets: 5500, revenue: 192500000, occupancy: 84 },
    { id: 'pontianak', name: 'Pontianak', province: 'Kalimantan Barat', cx: 450, cy: 280, tickets: 4000, revenue: 140000000, occupancy: 72 },
];
type CityId = typeof cityData[number]['id'];


function DatePicker({ date, setDate }: { date?: Date, setDate: (date?: Date) => void }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant={"outline"}
          className={cn(
            "w-full justify-start text-left font-normal",
            !date && "text-muted-foreground"
          )}
        >
          <CalendarDays className="mr-2 h-4 w-4" />
          {date ? format(date, "PPP") : <span>Pilih tanggal</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode="single"
          selected={date}
          onSelect={setDate}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  )
}

const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

const InteractiveMap = () => {
    const [hovered, setHovered] = useState<CityId | null>(null);
    const [position, setPosition] = useState({ x: 0, y: 0 });

    const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
      const rect = e.currentTarget.getBoundingClientRect();
      setPosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    };
    
    const data = hovered ? cityData.find(c => c.id === hovered) : null;

    return (
      <div className="relative w-full h-full min-h-[450px]" onMouseMove={handleMouseMove}>
        <svg viewBox="0 0 1000 500" className="w-full h-full">
          <g>
            {cityData.map((city) => (
              <Link href={`/dashboard/locations/${city.id}`} key={city.id}>
                <g
                  onMouseEnter={() => setHovered(city.id)}
                  onMouseLeave={() => setHovered(null)}
                  className="cursor-pointer group"
                >
                  <circle
                    cx={city.cx}
                    cy={city.cy}
                    r={hovered === city.id ? "12" : "8"}
                    className={`transition-all duration-200 stroke-border group-hover:stroke-primary ${hovered === city.id ? 'fill-primary' : 'fill-muted/50'}`}
                    strokeWidth="2"
                  />
                  <text
                    x={city.cx}
                    y={city.cy + (hovered === city.id ? 28 : 24)}
                    textAnchor="middle"
                    className={`transition-all duration-200 text-xs pointer-events-none ${hovered === city.id ? 'fill-foreground font-semibold' : 'fill-muted-foreground'}`}
                  >
                    {city.name}
                  </text>
                </g>
              </Link>
            ))}
          </g>
        </svg>

        {data && (
          <div
            className="absolute z-10 p-4 rounded-lg shadow-2xl pointer-events-none bg-card/80 backdrop-blur-sm border border-border w-64 animate-in fade-in-0 zoom-in-95"
            style={{ 
              top: Math.min(position.y + 20, 300), 
              left: position.x > 500 ? position.x - 280 : position.x + 20
            }}
          >
            <h4 className="font-bold text-lg text-primary mb-2">{data.name}</h4>
            <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Provinsi</span>
                    <span className="font-semibold">{data.province}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Tiket Terjual</span>
                    <span className="font-semibold">{data.tickets.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Revenue</span>
                    <span className="font-semibold">{formatCurrency(data.revenue)}</span>
                </div>
                <div className="flex justify-between items-center pt-1">
                    <span className="text-muted-foreground">Okupansi</span>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{data.occupancy.toFixed(1)}%</span>
                      <Progress value={data.occupancy} className="w-20 h-2" />
                    </div>
                </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3 italic">Klik untuk melihat detail</p>
          </div>
        )}
      </div>
    );
};


export default function DashboardPage() {
  const { user } = useUser();
  const [date, setDate] = React.useState<Date>()

  return (
    <div className="space-y-6">

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle>Filter Global</CardTitle>
            <CardDescription>Filter data di seluruh dasbor.</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex flex-col space-y-1.5">
                  <Label>Rentang Tanggal</Label>
                  <DatePicker date={date} setDate={setDate} />
              </div>
              <div className="flex flex-col space-y-1.5">
                  <Label>Lokasi</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Pilih Lokasi" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="semua">Semua Lokasi</SelectItem>
                      <SelectItem value="jakarta">Jakarta</SelectItem>
                      <SelectItem value="bandung">Bandung</SelectItem>
                    </SelectContent>
                  </Select>
              </div>
              <div className="flex flex-col space-y-1.5">
                  <Label>Franchise</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Pilih Franchise" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="semua">Semua Franchise</SelectItem>
                      <SelectItem value="xxi">XXI</SelectItem>
                      <SelectItem value="cgv">CGV</SelectItem>
                      <SelectItem value="cinepolis">Cinepolis</SelectItem>
                    </SelectContent>
                  </Select>
              </div>
              <div className="flex flex-col space-y-1.5">
                  <Label>Film</Label>
                   <Select>
                    <SelectTrigger><SelectValue placeholder="Pilih Film" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="semua">Semua Film</SelectItem>
                      <SelectItem value="dune">Dune: Bagian Tiga</SelectItem>
                      <SelectItem value="nusantara">Nusantara Chronicles</SelectItem>
                    </SelectContent>
                  </Select>
              </div>
          </div>
        </CardContent>
      </Card>


      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        <div className="xl:col-span-3 space-y-6">
           <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">Rp 1.24M</div>
                  <p className="text-xs text-green-400 flex items-center">
                      <ArrowUp className="h-3 w-3 mr-1" />
                      +8.7% vs kemarin
                    </p>
                </CardContent>
              </Card>
               <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Tiket</CardTitle>
                  <Ticket className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">24,891</div>
                    <p className="text-xs text-green-400 flex items-center">
                      <ArrowUp className="h-3 w-3 mr-1" />
                      +12.4% vs kemarin
                    </p>
                </CardContent>
              </Card>
               <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Okupansi</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">73.2%</div>
                   <p className="text-xs text-green-400 flex items-center">
                      <ArrowUp className="h-3 w-3 mr-1" />
                      +5.1% vs kemarin
                    </p>
                </CardContent>
              </Card>
               <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Film Tayang</CardTitle>
                  <Film className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">18</div>
                   <p className="text-xs text-muted-foreground">
                      2 Rilis Baru
                    </p>
                </CardContent>
              </Card>
          </div>

          <Card className="lg:col-span-2">
              <CardHeader>
                  <CardTitle>Peta Kinerja Kota</CardTitle>
                  <CardDescription>Arahkan kursor atau klik sebuah kota untuk melihat detail.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                  <InteractiveMap />
              </CardContent>
          </Card>
        </div>

        <div className="xl:col-span-2 space-y-6">
           <Card>
              <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Notifikasi & Alert</CardTitle>
                    <Link href="#" className="text-xs text-primary hover:underline">Lihat Semua</Link>
                  </div>
              </CardHeader>
              <CardContent className="space-y-3">
                  {notificationsData.map((n, i) => (
                      <Dialog key={i}>
                          <DialogTrigger asChild>
                              <div className={`relative overflow-hidden rounded-lg border p-3 cursor-pointer hover:bg-secondary/50 transition-all ${n.read ? 'opacity-60' : ''}`}>
                                  {!n.read && <div className="absolute top-2 right-2 h-2 w-2 rounded-full bg-primary animate-pulse"></div>}
                                  <div className="flex items-start gap-3">
                                      {n.icon}
                                      <div className="w-full">
                                          <p className="font-semibold text-xs">{n.title}</p>
                                          <p className="text-xs text-muted-foreground mt-1 truncate">{n.description}</p>
                                      </div>
                                  </div>
                              </div>
                          </DialogTrigger>
                          <DialogContent>
                              <DialogHeader>
                                  <DialogTitle className="flex items-center gap-3">
                                      {n.icon}
                                      {n.title}
                                  </DialogTitle>
                                  <DialogDescription>
                                      {n.description}
                                  </DialogDescription>
                              </DialogHeader>
                              <div className="mt-4">
                                  <h3 className="font-semibold mb-2">Event History</h3>
                                  <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Status</TableHead>
                                            <TableHead>Timestamp</TableHead>
                                            <TableHead>Detail</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {n.history.map((h, index) => (
                                            <TableRow key={index}>
                                                <TableCell><Badge variant={n.type === 'ALERT' ? 'destructive' : 'secondary'}>{h.status}</Badge></TableCell>
                                                <TableCell>{h.time}</TableCell>
                                                <TableCell>{h.detail}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                  </Table>
                              </div>
                          </DialogContent>
                      </Dialog>
                  ))}
              </CardContent>
          </Card>
          <Card>
              <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                      Live Transaksi
                      <div className="relative flex h-3 w-3 ml-auto">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                      </div>
                  </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                  {liveTransactions.map((t, i) => (
                      <div key={i} className="flex items-center gap-4">
                           <div className="p-2 bg-secondary rounded-lg">
                             <Ticket className="h-5 w-5 text-primary" />
                           </div>
                           <div className="flex-1 min-w-0">
                               <p className="text-sm font-medium truncate">{t.movie}</p>
                               <p className="text-xs text-muted-foreground truncate">{t.city}</p>
                           </div>
                           <div className="text-right flex-shrink-0">
                               <p className="text-sm font-bold text-green-400">+{t.tickets} tiket</p>
                               <p className="text-xs text-muted-foreground">{t.time}</p>
                           </div>
                      </div>
                  ))}
              </CardContent>
          </Card>
        </div>
      </div>
      
       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
             <Card className="h-full">
                <CardHeader>
                    <CardTitle>Okupansi Per Jam</CardTitle>
                    <CardDescription>Rata-rata okupansi studio per jam dalam periode yang dipilih.</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px] pr-0 -ml-4">
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={hourlyOccupancyData} margin={{ top: 5, right: 20, left: -10, bottom: 0 }}>
                            <defs>
                                <linearGradient id="occupancyGradient" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.4} />
                                <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <XAxis dataKey="hour" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}%`} />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: "hsl(var(--card))",
                                    borderColor: "hsl(var(--border))",
                                }}
                                formatter={(value) => [`${value}%`, "Okupansi"]}
                                cursor={{ stroke: "hsl(var(--primary))", strokeDasharray: "4 4" }}
                            />
                            <Area type="monotone" dataKey="Okupansi" stroke="hsl(var(--primary))" fill="url(#occupancyGradient)" strokeWidth={2} />
                        </AreaChart>
                     </ResponsiveContainer>
                </CardContent>
                <CardFooter className="flex items-center justify-center gap-x-8 text-xs text-muted-foreground -mt-4">
                     <div className="flex items-center gap-2">
                        <div className="h-2.5 w-2.5 rounded-full bg-primary/30"></div>
                        <span>Okupansi Rendah (&lt;40%)</span>
                    </div>
                     <div className="flex items-center gap-2">
                        <div className="h-2.5 w-2.5 rounded-full bg-primary/70"></div>
                        <span>Okupansi Sedang (40-70%)</span>
                    </div>
                     <div className="flex items-center gap-2">
                        <div className="h-2.5 w-2.5 rounded-full bg-primary"></div>
                        <span>Okupansi Tinggi (&gt;70%)</span>
                    </div>
                 </CardFooter>
            </Card>
          </div>
          <div>
             <Card className="h-full">
                <CardHeader className="flex flex-row items-center">
                    <div className="grid gap-2">
                        <CardTitle>Top 7 Film Terlaris</CardTitle>
                        <CardDescription>Peringkat film berdasarkan total tiket terjual hari ini.</CardDescription>
                    </div>
                    <Button asChild size="sm" className="ml-auto gap-1">
                        <Link href="/dashboard/films">
                        Lihat Semua
                        </Link>
                    </Button>
                </CardHeader>
                <CardContent className="space-y-3">
                    {topFilmsData.map(film => (
                        <div key={film.rank}>
                            <div className="flex justify-between text-sm mb-1">
                                <span className="font-semibold truncate max-w-[200px]">{film.rank}. {film.title}</span>
                                <span className="text-muted-foreground">Rp {film.revenue}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Progress value={(parseInt(film.tickets.replace(',', '')) / 5000) * 100} className="h-1.5" />
                                <span className="text-xs font-mono text-muted-foreground w-16 text-right">{film.tickets} tiket</span>
                            </div>
                        </div>
                    ))}
                </CardContent>
             </Card>
          </div>
      </div>
    </div>
  );
}
