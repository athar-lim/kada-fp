'use client';

import React from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Line,
  LineChart,
  Legend,
  CartesianGrid,
} from "recharts";
import { Clock, Ticket, DollarSign, Calendar, AlertTriangle, Users, Film, Clock4 } from 'lucide-react';
import { format, addMinutes, differenceInMinutes } from 'date-fns';
import { id } from 'date-fns/locale';

// ===========================
// DUMMY DATA
// ===========================

const movies = [
  { id: "M001", title: "Kung Fu Panda 4", genre: "Animation" },
  { id: "M002", title: "Dune: Part Two", genre: "Action" },
  { id: "M003", title: "Godzilla x Kong", genre: "Action" },
  { id: "M004", title: "Exhuma", genre: "Horror" },
  { id: "M005", title: "Siksa Kubur", genre: "Horror" },
  { id: "M006", title: "Badarawuhi di Desa Penari", genre: "Horror" },
  { id: "M007", title: "Civil War", genre: "Action" },
  { id: "M010", title: "Kingdom of the Planet of the Apes", genre: "Action" },
  { id: "M011", title: "Furiosa: A Mad Max Saga", genre: "Action" },
  { id: "M012", title: "Inside Out 2", genre: "Animation" },
  { id: "M013", title: "Deadpool & Wolverine", genre: "Action" },
  { id: "M014", title: "Despicable Me 4", genre: "Animation" },
  { id: "M015", title: "A Quiet Place: Day One", genre: "Horror" },
  { id: "M016", title: "Twisters", genre: "Action" },
  { id: "M017", title: "Alien: Romulus", genre: "Horror" },
  { id: "M018", title: "Joker: Folie à Deux", genre: "Drama" },
  { id: "M019", title: "Gladiator II", genre: "Action" },
  { id: "M020", title: "Moana 2", genre: "Animation" },
];

const cinemas = [
    { id: "C001", name: "Plaza Indonesia XXI", city: "Jakarta" },
    { id: "C002", name: "Paris Van Java CGV", city: "Bandung" },
    { id: "C003", name: "DP Mall Cinepolis", city: "Semarang" },
    { id: "C004", name: "Senayan City XXI", city: "Jakarta" },
    { id: "C005", name: "Trans Studio Mall XXI", city: "Bandung" },
];

const studios = [
    { id: "ST001", cinemaId: "C001", name: "Studio 1", capacity: 150, type: "2D" },
    { id: "ST002", cinemaId: "C001", name: "IMAX", capacity: 200, type: "IMAX" },
    { id: "ST003", cinemaId: "C002", name: "Studio 2", capacity: 120, type: "2D" },
    { id: "ST004", cinemaId: "C002", name: "Premiere", capacity: 40, type: "2D" },
    { id: "ST005", cinemaId: "C003", name: "Studio 1", capacity: 100, type: "2D" },
    { id: "ST006", cinemaId: "C003", name: "Studio 2", capacity: 80, type: "2D" },
    { id: "ST007", cinemaId: "C004", name: "Studio 1", capacity: 150, type: "2D" },
    { id: "ST008", cinemaId: "C004", name: "IMAX", capacity: 200, type: "IMAX" },
    { id: "ST009", cinemaId: "C005", name: "Studio 1", capacity: 120, type: "2D" },
    { id: "ST010", cinemaId: "C005", name: "Studio 2", capacity: 100, type: "2D" },
];

const schedules = Array.from({ length: 93 }).map((_, i) => {
    const date = new Date(2026, 2, 24 + (i % 6));
    const hour = 10 + Math.floor(Math.random() * 12);
    date.setHours(hour, Math.random() > 0.5 ? 30 : 0, 0, 0);

    let status: 'On-Time' | 'Delayed' | 'Cancelled';
    let delayMinutes = 0;
    const rand = Math.random();
    if (rand < 0.08) { // ~8% cancelled
        status = 'Cancelled';
    } else if (rand < 0.3) { // ~22% delayed
        status = 'Delayed';
        delayMinutes = 15 + Math.floor(Math.random() * 30);
    } else {
        status = 'On-Time';
    }
    
    const studio = studios[i % studios.length];

    return {
        id: `SCH${i + 1}`,
        movieId: movies[i % movies.length].id,
        studioId: studio.id,
        cinemaId: studio.cinemaId,
        scheduledTime: date,
        actualTime: status === 'Delayed' ? addMinutes(date, delayMinutes) : date,
        status,
        delayMinutes,
        capacity: studio.capacity,
    };
});

const seatCategories = [
    { name: 'Regular', price: 35000 },
    { name: 'VIP', price: 90000 }, // Average price
    { name: 'Sweetbox', price: 150000 },
]

const tickets = Array.from({ length: 270 }).map((_, i) => {
    const schedule = schedules[i % schedules.filter(s => s.status !== 'Cancelled').length];
    const seatCategoryRand = Math.random();
    let seatCategory;
    if(seatCategoryRand < 0.7) seatCategory = seatCategories[0];
    else if (seatCategoryRand < 0.9) seatCategory = seatCategories[1];
    else seatCategory = seatCategories[2];

    return {
        id: `T${i + 1}`,
        scheduleId: schedule.id,
        movieId: schedule.movieId,
        cinemaId: schedule.cinemaId,
        seatCategory: seatCategory.name,
        price: seatCategory.price,
        purchaseTime: new Date(schedule.scheduledTime.getTime() - Math.random() * 24 * 60 * 60 * 1000),
        paymentType: ['QRIS', 'Cash', 'CC'][i % 3],
    };
});


// ===========================
// DATA PROCESSING & CALCULATIONS
// ===========================

const totalTickets = tickets.length;
const totalRevenue = tickets.reduce((acc, t) => acc + t.price, 0);
const avgTicketsPerDay = totalTickets / 6;

const ticketsPerDay = Array.from({ length: 6 }).map((_, i) => {
    const day = 24 + i;
    const count = tickets.filter(t => t.purchaseTime.getDate() === day).length;
    return { date: `2026-03-${day}`, name: `${day} Mar`, tickets: count };
});

const revenuePerMovie = movies.map(movie => {
    const movieTickets = tickets.filter(t => t.movieId === movie.id);
    const revenue = movieTickets.reduce((acc, t) => acc + t.price, 0);
    return { name: movie.title, revenue };
}).sort((a, b) => b.revenue - a.revenue);

const occupancyPerCinema = cinemas.map(cinema => {
    const cinemaSchedules = schedules.filter(s => s.cinemaId === cinema.id && s.status !== 'Cancelled');
    const totalCapacity = cinemaSchedules.reduce((acc, s) => acc + s.capacity, 0);
    const ticketsSold = tickets.filter(t => t.cinemaId === cinema.id).length;
    const occupancy = totalCapacity > 0 ? (ticketsSold / totalCapacity) * 100 : 0;
    return {
        name: cinema.name,
        city: cinema.city,
        tickets: ticketsSold,
        capacity: totalCapacity,
        occupancy: occupancy,
    };
});

const avgTicketPricePerMovie = movies.map(movie => {
    const movieTickets = tickets.filter(t => t.movieId === movie.id);
    const prices = { Regular: [], VIP: [], Sweetbox: [] };
    movieTickets.forEach(t => {
        if(t.seatCategory === 'Regular') prices.Regular.push(t.price);
        else if(t.seatCategory === 'VIP') prices.VIP.push(t.price);
        else if(t.seatCategory === 'Sweetbox') prices.Sweetbox.push(t.price);
    });
    const avg = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
    return {
        name: movie.title.length > 15 ? movie.title.substring(0, 12) + '...' : movie.title,
        "Regular": avg(prices.Regular),
        "VIP": avg(prices.VIP),
        "Sweetbox": avg(prices.Sweetbox),
        "Overall Avg": avg([...prices.Regular, ...prices.VIP, ...prices.Sweetbox]),
    }
}).filter(m => m['Overall Avg'] > 0);


const ticketsByHour = Array.from({length: 14}).map((_, i) => {
    const hour = i + 10;
    const count = tickets.filter(t => t.purchaseTime.getHours() === hour).length;
    return { hour: `${hour}:00`, tickets: count };
});
const peakHoursData = ticketsByHour.slice().sort((a, b) => b.tickets - a.tickets);
const busiestHour = peakHoursData[0].hour;
const quietestHour = peakHoursData[peakHoursData.length-1].hour;

const cancelledShows = schedules.filter(s => s.status === 'Cancelled').length;
const delayedShows = schedules.filter(s => s.status === 'Delayed').length;
const totalDelayMinutes = schedules.reduce((acc, s) => acc + s.delayMinutes, 0);
const avgDelay = delayedShows > 0 ? Math.round(totalDelayMinutes / delayedShows) : 0;
const sortedSchedules = [...schedules].sort((a, b) => {
    const statusOrder = { 'Cancelled': 0, 'Delayed': 1, 'On-Time': 2 };
    return statusOrder[a.status] - statusOrder[b.status] || b.scheduledTime.getTime() - a.scheduledTime.getTime();
});

const monthlyRevenueData = [
  { month: 'Sep', revenue: 450 }, { month: 'Oct', revenue: 520 },
  { month: 'Nov', revenue: 610 }, { month: 'Dec', revenue: 800 },
  { month: 'Jan', revenue: 750 }, { month: 'Feb', revenue: 950 },
];

const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);
}

// ===========================
// PAGE COMPONENT
// ===========================

export default function SalesAnalyticsPage() {
    return (
        <div className="space-y-8">
            {/* PAGE HEADER */}
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-foreground">Sales Analytics</h1>
                    <p className="text-muted-foreground">Periode: 24–29 Maret 2026</p>
                </div>
                <div className="w-64">
                    <Select defaultValue="semua">
                        <SelectTrigger>
                            <SelectValue placeholder="Filter Bioskop" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="semua">Semua Bioskop</SelectItem>
                            {cinemas.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <Separator />
            
            {/* SECTION 1 — TOTAL TIKET TERJUAL */}
            <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">TOTAL TIKET TERJUAL</h2>
                    <p className="text-sm text-muted-foreground">Analisis tren penjualan tiket harian.</p>
                </header>
                <div className="grid gap-6 md:grid-cols-3">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Tiket</CardTitle>
                            <Ticket className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{totalTickets}</div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{formatCurrency(totalRevenue)}</div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Rata-rata per Hari</CardTitle>
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{avgTicketsPerDay.toFixed(0)} tiket/hari</div>
                        </CardContent>
                    </Card>
                </div>
                <Card>
                    <CardContent className="pt-6">
                        <Tabs defaultValue="hari" className="w-full">
                          <TabsList>
                            <TabsTrigger value="hari">Hari</TabsTrigger>
                            <TabsTrigger value="minggu">Minggu</TabsTrigger>
                            <TabsTrigger value="bulan">Bulan</TabsTrigger>
                          </TabsList>
                           <TabsContent value="hari" className="h-[250px] pt-6">
                                <ResponsiveContainer width="100%" height="100%">
                                    <LineChart data={ticketsPerDay}>
                                        <defs>
                                            <filter id="glow">
                                              <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                                              <feMerge>
                                                <feMergeNode in="coloredBlur" />
                                                <feMergeNode in="SourceGraphic" />
                                              </feMerge>
                                            </filter>
                                        </defs>
                                        <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                        <Tooltip
                                            contentStyle={{
                                                backgroundColor: "hsl(var(--card))",
                                                borderColor: "hsl(var(--border))",
                                            }}
                                        />
                                        <Line type="monotone" dataKey="tickets" stroke="hsl(var(--primary))" strokeWidth={2} style={{filter: "url(#glow)"}} />
                                    </LineChart>
                                </ResponsiveContainer>
                           </TabsContent>
                           <TabsContent value="minggu" className="flex items-center justify-center py-10">
                                <p className="text-muted-foreground">Data belum tersedia untuk periode ini</p>
                           </TabsContent>
                           <TabsContent value="bulan" className="flex items-center justify-center py-10">
                               <p className="text-muted-foreground">Data belum tersedia untuk periode ini</p>
                           </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </section>

            <Separator />

            {/* SECTION 2 - REVENUE 6 BULAN */}
            <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">REVENUE 6 BULAN</h2>
                    <p className="text-sm text-muted-foreground">Tren pendapatan franchise.</p>
                </header>
                <Card>
                    <CardHeader>
                        <CardTitle>Revenue 6 Bulan</CardTitle>
                        <CardDescription>Tren pendapatan franchise selama 6 bulan terakhir.</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[250px]">
                         <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={monthlyRevenueData}>
                                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `Rp${value}jt`} />
                                <Tooltip
                                    contentStyle={{
                                        backgroundColor: "hsl(var(--card))",
                                        borderColor: "hsl(var(--border))",
                                    }}
                                    cursor={{fill: 'hsl(var(--secondary))'}}
                                    formatter={(value) => `Rp ${Number(value)}jt`}
                                />
                                <Bar dataKey="revenue" radius={[4, 4, 0, 0]}>
                                    {monthlyRevenueData.map((entry, index) => (
                                        <Bar key={`cell-${index}`} fill={index === monthlyRevenueData.length - 1 ? "hsl(var(--primary))" : "hsl(var(--chart-5))"} />
                                    ))}
                                </Bar>
                            </BarChart>
                         </ResponsiveContainer>
                    </CardContent>
                </Card>
            </section>
            
            <Separator />
            
            {/* SECTION 3 — REVENUE & OKUPANSI */}
            <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">REVENUE & OKUPANSI</h2>
                    <p className="text-sm text-muted-foreground">Analisis pendapatan per film dan tingkat keterisian kursi per bioskop.</p>
                </header>
                 <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-5">
                    <div className="lg:col-span-3">
                        <Card>
                            <CardHeader>
                                <CardTitle>Revenue per Film</CardTitle>
                            </CardHeader>
                            <CardContent className="h-[350px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={revenuePerMovie.slice(0, 7)} layout="vertical">
                                        <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `Rp${Number(value) / 1000000}jt`} />
                                        <YAxis type="category" dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} width={120} />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                            cursor={{fill: 'hsl(var(--secondary))'}}
                                            formatter={(value) => formatCurrency(Number(value))}
                                        />
                                        <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={20} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </div>
                    <div className="lg:col-span-2">
                        <Card>
                            <CardHeader>
                                <CardTitle>Okupansi per Bioskop</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Bioskop</TableHead>
                                            <TableHead className="text-right">Okupansi</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {occupancyPerCinema.map((f, i) => (
                                            <TableRow key={i}>
                                                <TableCell>
                                                    <div className="font-medium">{f.name}</div>
                                                    <div className="text-sm text-muted-foreground">{f.city}</div>
                                                </TableCell>
                                                <TableCell className="text-right">
                                                    <div className="flex items-center justify-end gap-2">
                                                        <span className="w-12 text-right font-medium">{f.occupancy.toFixed(1)}%</span>
                                                        <Progress 
                                                            value={f.occupancy} 
                                                            className={`h-2 w-20 [&>div]:bg-green-500 ${f.occupancy < 40 ? '[&>div]:bg-red-500' : f.occupancy < 70 ? '[&>div]:bg-amber-500' : '' }`} 
                                                        />
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </section>
            
             <Separator />

            {/* SECTION 4 — AVERAGE TICKET PRICE */}
            <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">HARGA TIKET RATA-RATA</h2>
                    <p className="text-sm text-muted-foreground">Perbandingan harga tiket rata-rata per film berdasarkan kategori kursi.</p>
                </header>
                 <Card>
                    <CardHeader>
                        <CardTitle>Harga Rata-rata per Kategori Kursi</CardTitle>
                    </CardHeader>
                    <CardContent className="h-[280px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={avgTicketPricePerMovie.slice(0, 8)}>
                                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `Rp${Number(value)/1000}k`} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                    cursor={{fill: 'hsl(var(--secondary))'}}
                                    formatter={(value) => formatCurrency(Number(value))}
                                />
                                <Legend wrapperStyle={{fontSize: "12px"}} />
                                <Bar dataKey="Regular" fill="hsl(var(--muted))" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="VIP" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="Sweetbox" fill="hsl(var(--chart-4))" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </section>
            
             <Separator />

            {/* SECTION 5 — PEAK HOURS */}
            <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">JAM PUNCAK (PEAK HOURS)</h2>
                    <p className="text-sm text-muted-foreground">Distribusi penjualan tiket berdasarkan jam tayang.</p>
                </header>
                 <Card>
                    <CardHeader>
                        <CardTitle>Tiket Terjual per Jam</CardTitle>
                    </CardHeader>
                    <CardContent className="h-[280px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={ticketsByHour}>
                                <XAxis dataKey="hour" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}
                                    cursor={{fill: 'hsl(var(--secondary))'}}
                                />
                                <Bar dataKey="tickets" radius={[4, 4, 0, 0]}>
                                    {ticketsByHour.map((entry, index) => (
                                        <Bar key={`cell-${index}`} fill={
                                            peakHoursData.slice(0, 3).some(p => p.hour === entry.hour) 
                                            ? "hsl(var(--primary))" 
                                            : "hsl(var(--chart-5))"
                                        } />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
                 <div className="grid gap-6 md:grid-cols-3">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Jam Tersibuk</CardTitle>
                            <Clock4 className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{busiestHour}</div>
                            <p className="text-xs text-muted-foreground">Volume tiket tertinggi</p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Jam Sepi</CardTitle>
                            <Clock className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{quietestHour}</div>
                            <p className="text-xs text-muted-foreground">Volume tiket terendah</p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Rekomendasi Promo</CardTitle>
                            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-base font-semibold">Promo jam {quietestHour}</div>
                            <p className="text-xs text-muted-foreground">Pertimbangkan diskon untuk meningkatkan okupansi.</p>
                        </CardContent>
                    </Card>
                </div>
            </section>
            
            <Separator />

            {/* SECTION 6 — CANCELLED & DELAYED SHOWS */}
             <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">JADWAL BERMASALAH</h2>
                    <p className="text-sm text-muted-foreground">Ringkasan jadwal yang dibatalkan dan ditunda.</p>
                </header>
                 <div className="grid gap-6 md:grid-cols-3">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Jadwal Batal</CardTitle>
                            <AlertTriangle className="h-4 w-4 text-red-500" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{cancelledShows} jadwal</div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Jadwal Tunda</CardTitle>
                            <Clock className="h-4 w-4 text-amber-500" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{delayedShows} jadwal</div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Rata-rata Penundaan</CardTitle>
                            <Clock4 className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{avgDelay} menit</div>
                        </CardContent>
                    </Card>
                </div>
                <Card>
                    <CardHeader>
                       <div className="flex justify-between items-center">
                            <CardTitle>Daftar Jadwal Bermasalah</CardTitle>
                             <div className="w-48">
                                <Select defaultValue="semua">
                                    <SelectTrigger>
                                        <SelectValue placeholder="Filter Status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="semua">Semua Status</SelectItem>
                                        <SelectItem value="cancelled">Cancelled</SelectItem>
                                        <SelectItem value="delayed">Delayed</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                       </div>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Film</TableHead>
                                    <TableHead>Bioskop</TableHead>
                                    <TableHead>Jadwal Awal</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Keterangan</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {sortedSchedules.slice(0, 10).map((s) => (
                                    <TableRow key={s.id}>
                                        <TableCell className="font-medium">{movies.find(m => m.id === s.movieId)?.title}</TableCell>
                                        <TableCell>{cinemas.find(c => c.id === s.cinemaId)?.name}</TableCell>
                                        <TableCell>{format(s.scheduledTime, 'dd MMM yyyy, HH:mm', { locale: id })}</TableCell>
                                        <TableCell>
                                             <Badge variant={s.status === 'Cancelled' ? 'destructive' : 'default'} className={`${s.status === 'On-Time' ? 'bg-green-500/20 text-green-400 border-green-500/30' : s.status === 'Delayed' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30'}`}>
                                                {s.status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            {s.status === 'Delayed' ? `${s.delayMinutes} min delay` : s.status === 'Cancelled' ? 'Dibatalkan' : '-'}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </section>
        </div>
    );
}
    