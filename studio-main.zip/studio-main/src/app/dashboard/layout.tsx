"use client";

import { useUser } from "@/firebase";
import {
  LayoutDashboard,
  Loader2,
  Settings,
  Bell,
  Video,
  Clapperboard,
  BarChart2,
} from "lucide-react";
import {
  Sidebar,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";

function LiveClock() {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setTime(new Date());
        }, 1000);

        return () => {
            clearInterval(timer);
        };
    }, []);

    const formatDate = (date: Date) => {
        const options: Intl.DateTimeFormatOptions = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        };
        return date.toLocaleDateString('id-ID', options);
    };

    const formatTime = (date: Date) => {
        return date.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        }) + " WIB";
    }

    return (
        <div className="flex items-center gap-4">
             <div className="flex items-center gap-2">
                <div className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </div>
                <span className="text-sm font-medium text-green-400">LIVE</span>
            </div>
            <div className="text-sm text-muted-foreground">
                <span>{formatDate(time)}</span> | <span>{formatTime(time)}</span>
            </div>
        </div>
    );
}


export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, isUserLoading: loading } = useUser();
  const pathname = usePathname();

  if (loading && !user) {
    return (
      <div className="flex h-screen w-full flex-col items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Loading Dashboard...</p>
      </div>
    );
  }

  const menuUtama = [
    { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/dashboard/films", icon: Video, label: "Film Performance" },
    { href: "/dashboard/sales", icon: BarChart2, label: "Sales Analytics" },
  ];

  const sistemMenu = [
      { href: "/dashboard/notifications", icon: Bell, label: "Notifikasi", badge: "4" },
      { href: "/dashboard/settings", icon: Settings, label: "Pengaturan" },
  ]

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader className="p-4">
          <Link href="/dashboard" className="flex items-center gap-2">
            <Clapperboard className="h-8 w-8 text-primary" />
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tighter text-foreground">CINETRACK</span>
              <span className="text-xs text-muted-foreground -mt-1">Analytics Platform</span>
            </div>
          </Link>
        </SidebarHeader>
        <SidebarContent>
            <SidebarGroup>
                <SidebarGroupLabel>MENU UTAMA</SidebarGroupLabel>
                <SidebarMenu>
                    {menuUtama.map((item) => (
                    <SidebarMenuItem key={item.label}>
                        <Link href={item.href} passHref>
                        <SidebarMenuButton
                            isActive={pathname === item.href || (pathname.startsWith(item.href) && item.href !== '/dashboard')}
                            tooltip={item.label}
                        >
                            <item.icon />
                            <span>{item.label}</span>
                        </SidebarMenuButton>
                        </Link>
                    </SidebarMenuItem>
                    ))}
                </SidebarMenu>
            </SidebarGroup>
             <SidebarGroup>
                <SidebarGroupLabel>SISTEM</SidebarGroupLabel>
                <SidebarMenu>
                    {sistemMenu.map((item) => (
                    <SidebarMenuItem key={item.label}>
                        <Link href={item.href} passHref>
                        <SidebarMenuButton
                            isActive={pathname.startsWith(item.href)}
                            tooltip={item.label}
                        >
                            <item.icon />
                            <span>{item.label}</span>
                             {item.badge && <Badge className="ml-auto bg-primary text-primary-foreground">{item.badge}</Badge>}
                        </SidebarMenuButton>
                        </Link>
                    </SidebarMenuItem>
                    ))}
                </SidebarMenu>
            </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>
          <div className="flex items-center gap-3 p-4 border-t border-sidebar-border">
            <Avatar className="h-10 w-10">
                <AvatarImage src={user?.photoURL ?? "https://i.pravatar.cc/150?u=guest"} />
                <AvatarFallback>{user?.displayName ? user.displayName.charAt(0) : 'G'}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
                <p className="text-sm font-semibold text-foreground">{user?.isAnonymous ? 'Guest' : (user?.displayName || "Admin User")}</p>
                <p className="text-xs text-muted-foreground">{user?.isAnonymous ? 'Guest' : "Super Admin"}</p>
            </div>
            <div className="ml-auto h-2.5 w-2.5 rounded-full bg-green-500 ring-2 ring-green-500/20"></div>
          </div>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b bg-background px-6">
           <div className="flex items-center gap-4">
             <SidebarTrigger />
             <h1 className="text-lg font-semibold text-foreground">
                {pathname === '/dashboard' ? 'DASHBOARD' : ''}
             </h1>
           </div>
           <div className="hidden md:block">
             <LiveClock />
           </div>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 sm:px-6 sm:py-6 md:gap-8 bg-[#0D0D0D]">
            {children}
            <svg width="0" height="0">
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                  <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
            </svg>
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
