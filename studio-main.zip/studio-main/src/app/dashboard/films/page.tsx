'use client';

import React from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
  Pie,
  PieChart,
  Cell
} from "recharts";
import { Film, Users, Ticket, Clapperboard, Star, BarChart2, TrendingUp, TrendingDown, Award, Crown, Medal } from 'lucide-react';

// ===========================
// DUMMY DATA
// ===========================

const movies = [
    { id: "M001", title: "Kung Fu Panda 4", genre: "Animation", rating: "SU", duration: 94 },
    { id: "M002", title: "Dune: Part Two", genre: "Action", rating: "R13", duration: 166 },
    { id: "M003", title: "Godzilla x Kong", genre: "Action", rating: "R13", duration: 115 },
    { id: "M004", title: "Exhuma", genre: "Horror", rating: "D17", duration: 134 },
    { id: "M005", title: "Siksa Kubur", genre: "Horror", rating: "D17", duration: 117 },
    { id: "M006", title: "Badarawuhi di Desa Penari", genre: "Horror", rating: "D17", duration: 122 },
    { id: "M007", title: "Civil War", genre: "Action", rating: "D17", duration: 109 },
    { id: "M010", title: "Kingdom of the Planet of the Apes", genre: "Action", rating: "R13", duration: 145 },
    { id: "M011", title: "Furiosa: A Mad Max Saga", genre: "Action", rating: "D17", duration: 148 },
    { id: "M012", title: "Inside Out 2", genre: "Animation", rating: "SU", duration: 96 },
    { id: "M013", title: "Deadpool & Wolverine", genre: "Action", rating: "D17", duration: 127 },
    { id: "M014", title: "Despicable Me 4", genre: "Animation", rating: "SU", duration: 94 },
    { id: "M015", title: "A Quiet Place: Day One", genre: "Horror", rating: "R13", duration: 99 },
    { id: "M016", title: "Twisters", genre: "Action", rating: "R13", duration: 122 },
    { id: "M017", title: "Alien: Romulus", genre: "Horror", rating: "D17", duration: 119 },
    { id: "M018", title: "Joker: Folie à Deux", genre: "Drama", rating: "D17", duration: 138 },
    { id: "M019", title: "Gladiator II", genre: "Action", rating: "D17", duration: 148 },
    { id: "M020", title: "Moana 2", genre: "Animation", rating: "SU", duration: 100 },
];

const cinemas = [
    { id: "C001", name: "Plaza Indonesia XXI", city: "Jakarta" },
    { id: "C002", name: "Paris Van Java CGV", city: "Bandung" },
    { id: "C003", name: "DP Mall Cinepolis", city: "Semarang" },
    { id: "C004", name: "Senayan City XXI", city: "Jakarta" },
    { id: "C005", name: "Trans Studio Mall XXI", city: "Bandung" },
];

const seatCategories = [
    { name: 'Regular', price: 35000 },
    { name: 'VIP', price: 90000 },
    { name: 'Sweetbox', price: 150000 },
];

// Generate tickets with weighted distribution
const tickets = [];
const genreWeights = { 'Action': 4, 'Horror': 5, 'Animation': 2, 'Drama': 1 };

for (let i = 0; i < 270; i++) {
    const movieWeights = movies.map(m => genreWeights[m.genre]);
    const totalWeight = movieWeights.reduce((a,b) => a+b, 0);
    let random = Math.random() * totalWeight;
    let selectedMovie;
    for(let j=0; j<movies.length; j++){
        random -= movieWeights[j];
        if(random <= 0){
            selectedMovie = movies[j];
            break;
        }
    }
    selectedMovie = selectedMovie || movies[0];

    let seatCategory;
    const seatRand = Math.random();
    if(selectedMovie.genre === 'Animation' && seatRand < 0.8) seatCategory = seatCategories[0]; // 80% Regular for Animation
    else if(selectedMovie.rating === 'D17' && seatRand < 0.6) seatCategory = seatCategories[Math.floor(Math.random() * 2) + 1]; // 60% VIP/Sweetbox for D17
    else if(seatRand < 0.7) seatCategory = seatCategories[0];
    else if (seatRand < 0.9) seatCategory = seatCategories[1];
    else seatCategory = seatCategories[2];

    tickets.push({
        id: `T${i + 1}`,
        movieId: selectedMovie.id,
        cinemaId: cinemas[i % cinemas.length].id,
        seatCategory: seatCategory.name,
        price: seatCategory.price,
    });
}

// Generate schedules and calculate occupancy
const schedules = movies.flatMap(movie => {
    return Array.from({length: Math.ceil(Math.random() * 5) + 3 }).map((_, i) => { // 3-8 schedules per movie
        const cinema = cinemas[i % cinemas.length];
        const capacity = 80 + Math.floor(Math.random() * 120); // 80-200 seats
        return {
            movieId: movie.id,
            cinemaId: cinema.id,
            capacity,
        }
    });
});

// ===========================
// DATA PROCESSING
// ===========================

const totalFilms = movies.length;
const totalTicketsSold = tickets.length;

const filmPerformance = movies.map(movie => {
    const movieTickets = tickets.filter(t => t.movieId === movie.id);
    const revenue = movieTickets.reduce((acc, t) => acc + t.price, 0);
    const seatDistribution = { Regular: 0, VIP: 0, Sweetbox: 0 };
    movieTickets.forEach(t => { seatDistribution[t.seatCategory]++; });

    const movieSchedules = schedules.filter(s => s.movieId === movie.id);
    const totalCapacity = movieSchedules.reduce((acc, s) => acc + s.capacity, 0);
    const occupancy = totalCapacity > 0 ? (movieTickets.length / totalCapacity) * 100 : 0;

    return {
        ...movie,
        tickets: movieTickets.length,
        revenue,
        avgPrice: movieTickets.length > 0 ? revenue / movieTickets.length : 0,
        seatDistribution,
        occupancy,
    };
}).sort((a, b) => b.tickets - a.tickets);

const topFilmLaris = filmPerformance[0];
const topFilmsByTickets = filmPerformance.slice(0, 3);
const filmsByRevenue = [...filmPerformance].sort((a, b) => b.revenue - a.revenue);
const filmsByOccupancy = [...filmPerformance].sort((a,b) => b.occupancy - a.occupancy);

const genrePerformance = Object.entries(
    tickets.reduce((acc, ticket) => {
        const movie = movies.find(m => m.id === ticket.movieId);
        if (movie) {
            if (!acc[movie.genre]) {
                acc[movie.genre] = { tickets: 0, revenue: 0, films: new Set() };
            }
            acc[movie.genre].tickets++;
            acc[movie.genre].revenue += ticket.price;
            acc[movie.genre].films.add(movie.id);
        }
        return acc;
    }, {})
).map(([genre, data]) => ({
    name: genre,
    ...data,
    filmCount: data.films.size,
    avgOccupancy: filmPerformance.filter(f=>f.genre === genre).reduce((acc, f, _, arr) => acc + f.occupancy / arr.length, 0),
}));

const topGenre = genrePerformance.sort((a, b) => b.tickets - a.tickets)[0].name;

const ratingPerformance = Object.entries(
    tickets.reduce((acc, ticket) => {
        const movie = movies.find(m => m.id === ticket.movieId);
        if (movie) {
            if (!acc[movie.rating]) {
                acc[movie.rating] = { tickets: 0, films: new Set(), Regular: 0, VIP: 0, Sweetbox: 0 };
            }
            acc[movie.rating].tickets++;
            acc[movie.rating].films.add(movie.id);
            acc[movie.rating][ticket.seatCategory]++;
        }
        return acc;
    }, {})
).map(([rating, data]) => ({ name: rating, ...data, filmCount: data.films.size }));

const ratingChartData = ratingPerformance.map(r => ({
    name: r.name,
    Regular: r.Regular,
    VIP: r.VIP,
    Sweetbox: r.Sweetbox,
}));

const cinemaFilmHeatmap = cinemas.map(cinema => {
    const filmData = movies.map(movie => {
        const ticketCount = tickets.filter(t => t.cinemaId === cinema.id && t.movieId === movie.id).length;
        return {
            film: movie.title,
            tickets: ticketCount,
        }
    });
    return {
        name: cinema.name,
        ...Object.fromEntries(filmData.map(f => [f.film, f.tickets]))
    };
});

const allCinemaFilmPairs = movies.flatMap(movie =>
    cinemas.map(cinema => ({
        film: movie.title,
        cinema: cinema.name,
        tickets: tickets.filter(t => t.movieId === movie.id && t.cinemaId === cinema.id).length,
    }))
).sort((a, b) => b.tickets - a.tickets);
const topCinemaFilmCombos = allCinemaFilmPairs.slice(0, 3);

// ===========================
// STYLE HELPERS
// ===========================

const formatCurrency = (value) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

const GENRE_COLORS = {
    Action: "hsl(var(--chart-3))", // Blue
    Horror: "hsl(var(--primary))",  // Red
    Animation: "hsl(var(--chart-2))", // Green
    Drama: "hsl(var(--chart-4))",   // Amber
};

const RATING_COLORS = {
    SU: 'bg-green-500/20 text-green-400 border-green-500/30',
    R13: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    D17: 'bg-red-500/20 text-red-400 border-red-500/30'
}

const getHeatmapColor = (value) => {
    if (value === 0) return 'bg-[#1A1A1A]';
    if (value <= 5) return 'bg-[#2A1A1A]';
    if (value <= 15) return 'bg-[#8B2020]';
    return 'bg-[#E24B4A]';
}

const PodiumIcon = ({ rank }) => {
    if (rank === 1) return <Crown className="h-6 w-6 text-yellow-400" />;
    if (rank === 2) return <Award className="h-6 w-6 text-slate-400" />;
    if (rank === 3) return <Medal className="h-6 w-6 text-amber-600" />;
    return null;
}


// ===========================
// PAGE COMPONENT
// ===========================

export default function FilmPerformancePage() {
    return (
        <div className="space-y-8">
            {/* PAGE HEADER */}
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-foreground">Film Performance</h1>
                    <p className="text-muted-foreground">Periode: 24–29 Maret 2026</p>
                </div>
                <div className="w-64">
                    <Select defaultValue="semua">
                        <SelectTrigger>
                            <SelectValue placeholder="Filter Bioskop" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="semua">Semua Bioskop</SelectItem>
                            {cinemas.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <Separator />
            
            {/* SECTION 1 — SUMMARY CARDS */}
            <section>
                <div className="grid gap-6 md:grid-cols-4">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Film Tayang</CardTitle>
                            <Film className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{totalFilms}</div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Film Terlaris</CardTitle>
                            <Star className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold truncate">{topFilmLaris.title}</div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Tiket Terjual</CardTitle>
                            <Ticket className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{totalTicketsSold}</div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Genre Terpopuler</CardTitle>
                            <Clapperboard className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{topGenre}</div>
                        </CardContent>
                    </Card>
                </div>
            </section>

            <Separator />
            
            {/* SECTION 2 — TOP FILM BY TIKET TERJUAL */}
            <section className="space-y-6">
                <header className="flex justify-between items-center">
                    <div>
                        <h2 className="text-lg font-semibold">TOP FILM — TIKET TERJUAL</h2>
                        <p className="text-sm text-muted-foreground">Peringkat film berdasarkan jumlah tiket yang terjual.</p>
                    </div>
                    <div className="flex gap-2">
                        <Select defaultValue="semua-genre">
                            <SelectTrigger className="w-40">
                                <SelectValue placeholder="Filter Genre" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="semua-genre">Semua Genre</SelectItem>
                                {Object.keys(GENRE_COLORS).map(g => <SelectItem key={g} value={g.toLowerCase()}>{g}</SelectItem>)}
                            </SelectContent>
                        </Select>
                        <Select defaultValue="semua-rating">
                            <SelectTrigger className="w-40">
                                <SelectValue placeholder="Filter Rating" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="semua-rating">Semua Rating</SelectItem>
                                {Object.keys(RATING_COLORS).map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                </header>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2">
                        <Card>
                            <CardContent className="h-[500px] pt-6 pr-8">
                                 <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={filmPerformance} layout="vertical" margin={{ left: 100 }}>
                                        <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                        <YAxis type="category" dataKey="title" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} width={150} />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                            cursor={{fill: 'hsl(var(--secondary))'}}
                                            formatter={(value, name) => [value, 'Tiket']}
                                        />
                                        <Bar dataKey="tickets" barSize={15}>
                                           {filmPerformance.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={index < 3 ? "hsl(var(--primary))" : "hsl(var(--border))"} />
                                            ))}
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </div>
                    <div className="space-y-4">
                        {topFilmsByTickets.map((film, index) => (
                            <Card key={film.id}>
                                <CardHeader>
                                    <div className="flex items-start justify-between">
                                        <PodiumIcon rank={index + 1} />
                                        <div className="text-right">
                                            <Badge variant="outline" className={RATING_COLORS[film.rating]}>{film.rating}</Badge>
                                        </div>
                                    </div>
                                    <CardTitle className="text-lg pt-2">{film.title}</CardTitle>
                                    <CardDescription>{film.genre} &bull; {film.duration} min</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex justify-between text-sm">
                                        <p className="text-muted-foreground">Tiket Terjual</p>
                                        <p className="font-bold">{film.tickets}</p>
                                    </div>
                                    <div className="flex justify-between text-sm mt-1">
                                        <p className="text-muted-foreground">Revenue</p>
                                        <p className="font-bold">{formatCurrency(film.revenue)}</p>
                                    </div>
                                    <div className="mt-4">
                                        <p className="text-xs text-muted-foreground mb-1">Kategori Kursi</p>
                                        <div className="flex h-2 rounded-full overflow-hidden">
                                            <div className="bg-gray-500" style={{ width: `${(film.seatDistribution.Regular / film.tickets) * 100}%` }}></div>
                                            <div className="bg-blue-500" style={{ width: `${(film.seatDistribution.VIP / film.tickets) * 100}%` }}></div>
                                            <div className="bg-amber-500" style={{ width: `${(film.seatDistribution.Sweetbox / film.tickets) * 100}%` }}></div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>
            
            <Separator />
            
            {/* SECTION 3 — REVENUE PER FILM */}
            <section className="space-y-6">
                 <header>
                    <h2 className="text-lg font-semibold">REVENUE PER FILM</h2>
                    <p className="text-sm text-muted-foreground">Peringkat film berdasarkan total pendapatan.</p>
                </header>
                 <Card>
                    <CardContent className="h-[350px] pt-6 -ml-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={filmsByRevenue}>
                                <XAxis dataKey="title" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} angle={-45} textAnchor="end" height={60} />
                                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `Rp${value / 1000000}M`} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                    cursor={{fill: 'hsl(var(--secondary))'}}
                                    formatter={(value) => formatCurrency(Number(value))}
                                />
                                <Bar dataKey="revenue" radius={[4, 4, 0, 0]}>
                                    {filmsByRevenue.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={GENRE_COLORS[entry.genre]} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                    <CardFooter className="flex-col items-start gap-4">
                        <div className="flex gap-4 justify-center w-full">
                           {Object.entries(GENRE_COLORS).map(([genre, color]) => (
                               <div key={genre} className="flex items-center gap-2 text-xs">
                                   <div className="w-3 h-3 rounded-full" style={{backgroundColor: color}}></div>
                                   <span>{genre}</span>
                               </div>
                           ))}
                        </div>
                        <Table>
                             <TableHeader>
                                <TableRow>
                                    <TableHead>Film</TableHead>
                                    <TableHead>Genre</TableHead>
                                    <TableHead>Rating</TableHead>
                                    <TableHead className="text-right">Tiket</TableHead>
                                    <TableHead className="text-right">Revenue</TableHead>
                                    <TableHead className="text-right">Avg. Price</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filmsByRevenue.slice(0,5).map(film => (
                                    <TableRow key={film.id}>
                                        <TableCell className="font-medium">{film.title}</TableCell>
                                        <TableCell><Badge variant="outline" style={{borderColor: GENRE_COLORS[film.genre], color: GENRE_COLORS[film.genre]}}>{film.genre}</Badge></TableCell>
                                        <TableCell><Badge variant="outline" className={RATING_COLORS[film.rating]}>{film.rating}</Badge></TableCell>
                                        <TableCell className="text-right">{film.tickets}</TableCell>
                                        <TableCell className="text-right font-semibold">{formatCurrency(film.revenue)}</TableCell>
                                        <TableCell className="text-right">{formatCurrency(film.avgPrice)}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardFooter>
                 </Card>
            </section>
            
            <Separator />

            {/* SECTION 4 — OCCUPANCY PER FILM */}
            <section className="space-y-6">
                <header>
                    <h2 className="text-lg font-semibold">OKUPANSI PER FILM</h2>
                    <p className="text-sm text-muted-foreground">Persentase kursi terisi dari total kapasitas studio per jadwal tayang.</p>
                </header>
                 <Card>
                    <CardContent className="h-[500px] pt-6 pr-8">
                         <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={filmsByOccupancy} layout="vertical" margin={{ left: 100 }}>
                                <XAxis type="number" domain={[0, 100]} stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}%`} />
                                <YAxis type="category" dataKey="title" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} width={150} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                    cursor={{fill: 'hsl(var(--secondary))'}}
                                    formatter={(value) => `${Number(value).toFixed(1)}%`}
                                />
                                <Bar dataKey="occupancy" barSize={15}>
                                   {filmsByOccupancy.map((entry, index) => {
                                        let color = "hsl(var(--primary))";
                                        if (entry.occupancy > 70) color = "hsl(var(--chart-2))";
                                        else if (entry.occupancy > 40) color = "hsl(var(--chart-4))";
                                        return <Cell key={`cell-${index}`} fill={color} />
                                    })}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
                <div className="grid gap-6 md:grid-cols-2">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Okupansi Tertinggi</CardTitle>
                            <TrendingUp className="h-4 w-4 text-green-500" />
                        </CardHeader>
                        <CardContent>
                            <p className="text-lg font-bold">{filmsByOccupancy[0].title}</p>
                            <p className="text-2xl font-bold text-green-400">{filmsByOccupancy[0].occupancy.toFixed(1)}%</p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Perlu Perhatian</CardTitle>
                            <TrendingDown className="h-4 w-4 text-red-500" />
                        </CardHeader>
                        <CardContent>
                            <p className="text-lg font-bold">{filmsByOccupancy[filmsByOccupancy.length-1].title}</p>
                            <p className="text-sm text-muted-foreground">Pertimbangkan pengurangan jadwal atau promo harga.</p>
                        </CardContent>
                    </Card>
                </div>
            </section>

            <Separator />
            
            {/* SECTION 5 — GENRE BREAKDOWN */}
            <section className="space-y-6">
                <h2 className="text-lg font-semibold">GENRE BREAKDOWN</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="flex items-center justify-center">
                        <CardContent className="h-[280px] pt-6">
                             <ResponsiveContainer width={280} height="100%">
                                <PieChart>
                                    <Pie data={genrePerformance} dataKey="tickets" nameKey="name" cx="50%" cy="50%" innerRadius={80} outerRadius={110} paddingAngle={5}>
                                        {genrePerformance.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={GENRE_COLORS[entry.name]} />
                                        ))}
                                    </Pie>
                                    <Tooltip
                                        contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                    />
                                </PieChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                    <div className="grid grid-cols-2 gap-6">
                        {genrePerformance.map(genre => (
                            <Card key={genre.name}>
                                <CardHeader>
                                    <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 rounded-full" style={{backgroundColor: GENRE_COLORS[genre.name]}}></div>
                                        <CardTitle className="text-base">{genre.name}</CardTitle>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-xs text-muted-foreground">Jumlah Film</p>
                                    <p className="font-semibold">{genre.filmCount}</p>
                                    <p className="text-xs text-muted-foreground mt-2">Total Tiket</p>
                                    <p className="font-semibold">{genre.tickets}</p>
                                    <p className="text-xs text-muted-foreground mt-2">Total Revenue</p>
                                    <p className="font-semibold">{formatCurrency(genre.revenue)}</p>
                                    <p className="text-xs text-muted-foreground mt-2">Avg Occupancy</p>
                                    <p className="font-semibold">{genre.avgOccupancy.toFixed(1)}%</p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

             <Separator />

            {/* SECTION 6 — RATING USIA BREAKDOWN */}
            <section className="space-y-6">
                <h2 className="text-lg font-semibold">DISTRIBUSI RATING USIA</h2>
                <div className="grid gap-6 md:grid-cols-3">
                    {ratingPerformance.map(rating => (
                        <Card key={rating.name}>
                            <CardHeader>
                                <CardTitle className="text-base flex items-center gap-2">
                                    <Badge variant="outline" className={RATING_COLORS[rating.name]}>{rating.name}</Badge>
                                    {rating.name === 'SU' ? 'Semua Umur' : rating.name === 'R13' ? '13+' : '17+'}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-xl font-bold">{rating.filmCount} Film</p>
                                <p className="text-lg text-muted-foreground">{rating.tickets} Tiket</p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
                <Card>
                    <CardHeader>
                        <CardTitle>Distribusi Kategori Kursi per Rating</CardTitle>
                    </CardHeader>
                    <CardContent className="h-[280px] -ml-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={ratingChartData}>
                                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))"}}
                                    cursor={{fill: 'hsl(var(--secondary))'}}
                                />
                                <Legend wrapperStyle={{fontSize: "12px"}}/>
                                <Bar dataKey="Regular" stackId="a" fill="hsl(var(--muted))" />
                                <Bar dataKey="VIP" stackId="a" fill={GENRE_COLORS.Action} />
                                <Bar dataKey="Sweetbox" stackId="a" fill={GENRE_COLORS.Drama} />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                    <CardFooter>
                        <p className="text-sm text-muted-foreground italic">
                            Film D17 cenderung dibeli dengan kategori seat premium (VIP/Sweetbox).
                        </p>
                    </CardFooter>
                </Card>
            </section>

             <Separator />

            {/* SECTION 7 — PERFORMA PER BIOSKOP PER FILM */}
             <section className="space-y-6">
                <h2 className="text-lg font-semibold">PERFORMA PER BIOSKOP</h2>
                 <Card>
                    <CardHeader>
                        <CardTitle>Heatmap Tiket per Film & Bioskop</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-[200px] px-2 py-3">Film</TableHead>
                                        {cinemas.map(c => <TableHead key={c.id} className="text-center px-2 py-3">{c.name}</TableHead>)}
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {filmPerformance.slice(0, 10).map(movie => (
                                        <TableRow key={movie.id}>
                                            <TableCell className="p-2 font-medium truncate max-w-[200px]">{movie.title}</TableCell>
                                            {cinemas.map(cinema => {
                                                const pair = allCinemaFilmPairs.find(p => p.film === movie.title && p.cinema === cinema.name);
                                                const ticketCount = pair ? pair.tickets : 0;
                                                return (
                                                     <TableCell key={cinema.id} className="text-center p-1">
                                                         <div className={`px-2 py-1 rounded-md ${getHeatmapColor(ticketCount)}`}>
                                                             {ticketCount}
                                                         </div>
                                                     </TableCell>
                                                )
                                            })}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                     <CardFooter className="flex-col items-start gap-4">
                        <h3 className="font-semibold">Film × Bioskop Terbaik</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                           {topCinemaFilmCombos.map((combo, i) => (
                               <div key={i} className="p-4 bg-secondary rounded-lg">
                                   <p className="font-bold text-sm truncate">{combo.film}</p>
                                   <p className="text-xs text-muted-foreground">{combo.cinema}</p>
                                   <p className="text-lg font-bold text-primary mt-2">{combo.tickets} Tiket</p>
                               </div>
                           ))}
                        </div>
                     </CardFooter>
                </Card>
            </section>
        </div>
    );
}
