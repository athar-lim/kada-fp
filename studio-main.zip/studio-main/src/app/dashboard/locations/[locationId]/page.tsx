'use client';

import React from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function LocationDetailPage({ params }: { params: { locationId: string } }) {
  // In a real app, you would fetch data based on params.locationId
  const locationName = params.locationId.charAt(0).toUpperCase() + params.locationId.slice(1);

  return (
    <div className="space-y-6">
       <div className="flex items-center gap-4">
        <Button asChild variant="outline" size="icon">
          <Link href="/dashboard">
            <ArrowLeft />
          </Link>
        </Button>
        <div>
           <h1 className="text-2xl font-bold text-foreground">Detail Lokasi: {locationName}</h1>
           <p className="text-muted-foreground">Menampilkan data performa untuk kota yang dipilih.</p>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Ringkasan Kinerja - {locationName}</CardTitle>
          <CardDescription>
            Ini adalah halaman detail untuk {locationName}. Di aplikasi nyata, halaman ini akan berisi bagan dan data spesifik untuk lokasi ini.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Data detail untuk {locationName} akan ditampilkan di sini.</p>
        </CardContent>
      </Card>
    </div>
  );
}
