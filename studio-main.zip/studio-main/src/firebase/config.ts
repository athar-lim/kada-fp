export const firebaseConfig = {
  "projectId": "studio-5115371107-1fff8",
  "appId": "1:213136504385:web:fff4977dd54603c821b8c0",
  "apiKey": "AIzaSyAFDol-l70aDN4IgET8FjbTjvlWrn88EV4",
  "authDomain": "studio-5115371107-1fff8.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "213136504385"
};
