"use server";

import {
  collection,
  writeBatch,
  doc,
  Timestamp,
} from "firebase/firestore";
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { firebaseConfig } from "@/firebase/config";
import type { Film, Location, SeatCategory, Studio, Showtime, Ticket } from "./types";
import { subDays, addHours } from "date-fns";
import { PlaceHolderImages } from "./placeholder-images";

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);

function getRandomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function getRandomNumber(min: number, max: number): number {
    return Math.random() * (max - min) + min;
}

export async function seedDatabase() {
  try {
    const batch = writeBatch(db);

    // 1. Seed Studios
    const studios: Omit<Studio, "id">[] = [
      { name: "CineVerse Pictures" },
      { name: "Starlight Studios" },
    ];
    const studioRefs = studios.map((studio) => {
      const ref = doc(collection(db, "studios"));
      batch.set(ref, studio);
      return { id: ref.id, ...studio };
    });

    // 2. Seed Films
    const filmsData: Omit<Film, "id" | "studioId" | "posterUrl">[] = [
        { title: "Galactic Echoes", director: "Ava Chen", releaseDate: Timestamp.fromDate(new Date("2023-05-20")), durationMinutes: 148 },
        { title: "The Last Cipher", director: "Ben Carter", releaseDate: Timestamp.fromDate(new Date("2023-08-11")), durationMinutes: 132 },
        { title: "Cobblestone Heart", director: "Diana Prince", releaseDate: Timestamp.fromDate(new Date("2023-11-02")), durationMinutes: 118 },
        { title: "Midnight Mirage", director: "Frank Miller", releaseDate: Timestamp.fromDate(new Date("2024-01-15")), durationMinutes: 125 },
        { title: "Quantum Leapfrog", director: "Grace Hopper", releaseDate: Timestamp.fromDate(new Date("2024-04-01")), durationMinutes: 95 },
    ];
    
    const filmRefs = filmsData.map((film, index) => {
        const ref = doc(collection(db, "films"));
        const placeholderImage = PlaceHolderImages[index % PlaceHolderImages.length];
        batch.set(ref, {
            ...film,
            studioId: getRandomElement(studioRefs).id,
            posterUrl: placeholderImage.imageUrl,
        });
        return { id: ref.id, ...film };
    });

    // 3. Seed Locations
    const locations: Omit<Location, "id">[] = [
      { name: "CineTrack Grand Plaza", city: "Jakarta", address: "Jl. Jenderal Sudirman No.Kav. 52-53" },
      { name: "CineTrack City Center", city: "Jakarta", address: "Jl. M.H. Thamrin No.1" },
      { name: "CineTrack Metro Point", city: "Bandung", address: "Jl. Peta No.241" },
      { name: "CineTrack Heritage Walk", city: "Bandung", address: "Jl. Cihampelas No.160" },
      { name: "CineTrack Bayfront", city: "Surabaya", address: "Jl. Mayjend. Jonosewojo No.2" },
    ];
    const locationRefs = locations.map((location) => {
      const ref = doc(collection(db, "locations"));
      batch.set(ref, location);
      return { id: ref.id, ...location };
    });

    // 4. Seed Seat Categories
    const seatCategories: Omit<SeatCategory, "id">[] = [
      { name: "Regular", basePriceMultiplier: 1.0 },
      { name: "VIP", basePriceMultiplier: 1.8 },
      { name: "Sweetbox", basePriceMultiplier: 2.5 },
    ];
    const seatCategoryRefs = seatCategories.map((cat) => {
      const ref = doc(collection(db, "seat_categories"));
      batch.set(ref, cat);
      return { id: ref.id, ...cat };
    });

    // 5. Seed Showtimes and Tickets
    const showtimeStatuses: Showtime['status'][] = ['on-time', 'on-time', 'on-time', 'on-time', 'cancelled', 'delayed'];
    const showtimeRefs: { id: string }[] = [];
    
    for (let i = 0; i < 60; i++) { // Last 60 days
      const date = subDays(new Date(), i);
      for (let j = 0; j < 15; j++) { // 15 showtimes per day
        const film = getRandomElement(filmRefs);
        const location = getRandomElement(locationRefs);
        const hour = getRandomNumber(10, 22);
        const minute = getRandomElement([0, 30]);
        date.setHours(hour, minute, 0, 0);

        const showtimeStatus = getRandomElement(showtimeStatuses);
        let showtimeDate = date;
        if(showtimeStatus === 'delayed') {
            showtimeDate = addHours(date, 1);
        }

        const showtime: Omit<Showtime, "id"> = {
          filmId: film.id,
          locationId: location.id,
          showtime: Timestamp.fromDate(showtimeDate),
          status: showtimeStatus,
          availableSeats: 100,
        };
        const showtimeRef = doc(collection(db, "showtimes"));
        batch.set(showtimeRef, showtime);
        showtimeRefs.push({ id: showtimeRef.id });
      }
    }
    
    // Create at least 500 tickets
    for (let i = 0; i < 600; i++) {
        const showtimeRef = getRandomElement(showtimeRefs);
        const seatCategory = getRandomElement(seatCategoryRefs);
        const price = Math.round((getRandomNumber(35000, 70000) * seatCategory.basePriceMultiplier) / 1000) * 1000;
        const purchaseTime = subDays(new Date(), getRandomNumber(1, 60));

        const ticket: Omit<Ticket, "id"> = {
            showtimeId: showtimeRef.id,
            seatCategoryId: seatCategory.id,
            price: price,
            purchaseTime: Timestamp.fromDate(purchaseTime),
            customerEmail: `customer${i}@example.com`,
        };
        const ticketRef = doc(collection(db, "tickets"));
        batch.set(ticketRef, ticket);
    }


    await batch.commit();
    return { success: true, message: "Database seeded successfully!" };
  } catch (error) {
    console.error("Error seeding database:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    return { success: false, message: `Failed to seed database: ${errorMessage}` };
  }
}
