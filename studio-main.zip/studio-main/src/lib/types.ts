import type { Timestamp } from "firebase/firestore";

export interface Film {
  id?: string;
  title: string;
  director: string;
  releaseDate: Timestamp;
  studioId: string;
  posterUrl: string;
  durationMinutes: number;
}

export interface Location {
  id?: string;
  name: string;
  city: string;
  address: string;
}

export interface Studio {
  id?: string;
  name: string;
}

export interface Showtime {
  id?: string;
  filmId: string;
  locationId: string;
  showtime: Timestamp;
  status: 'on-time' | 'cancelled' | 'delayed';
  availableSeats: number;
}

export interface Ticket {
  id?: string;
  showtimeId: string;
  seatCategoryId: string;
  price: number;
  purchaseTime: Timestamp;
  customerEmail: string;
}

export interface SeatCategory {
  id?: string;
  name: 'Regular' | 'VIP' | 'Sweetbox';
  basePriceMultiplier: number;
}
